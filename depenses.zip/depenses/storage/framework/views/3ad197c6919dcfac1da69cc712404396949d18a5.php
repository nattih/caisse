
<?php $__env->startSection('css'); ?>
    <style>
        .table {
            margin: auto;
            width: 90% !important;  
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 col-lg-12">
        <div class="card">
            <?php if($depenses->isNotEmpty()): ?>
                <h2 class="text-center">Liste des dépenses à valider</h2>
                <table class="table table-striped mb-2">
                    <thead>
                        <tr>
                            <th >Nature </th>
                            <th >Montant</th>
                            <th >Date</th>
                            <th >Fournisseur</th>
                            <th >Solde</th>
                            <th >statut</th>
                            <th >Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $depenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->designation); ?></td>
                                <td><?php echo e($item->montant); ?></td>
                                <td><?php echo e($item->dateDepense); ?></td>
                                <td><?php echo e($item->fournisseur); ?></td>
                                <td><?php echo e($item->nouveauSolde); ?></td>
                                <td>
                                    <?php switch($item->statut):
                                        case (0): ?>
                                            En cours...
                                            <?php break; ?>
                                        <?php case (1): ?>
                                            Validée
                                            <?php break; ?>
                                        <?php default: ?>
                                            Rejetée
                                    <?php endswitch; ?>
                                    
                                </td>
                                <td>
                                    <a href="<?php echo e(route('depense.show', $item->id)); ?>" class="btn btn-sm btn-success"> <i class="fas fa-eye"></i> Détails </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h3 class="text-center">Aucune dépense invalide trouvée!</h3>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Cours\Mes_professionnels\a2sys\depenses\resources\views/validations/depenses_to_validate.blade.php ENDPATH**/ ?>