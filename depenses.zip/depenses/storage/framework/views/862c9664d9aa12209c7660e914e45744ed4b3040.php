
<?php $__env->startSection('css'); ?>
    <style>
        .table {
            margin: auto;
            width: 90% !important;  
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 col-lg-12">
        <div class="card">
            <form class="form-horizontal" id="agent_form" action="<?php echo e(route('agent.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <fieldset>
                    <legend>Enregistrement d'un agent</legend>
                    <div class="row">
                        <div class="col-12 col-lg-6">
                            <div class="form-group row">
                                <label for="code" class="col-12 col-lg-4 text-right control-label col-form-label">Code:</label>
                                <div class="col-12 col-lg-8">
                                <input type="text" class="form-control" id="code" placeholder="Saisir le code" name="code" value="<?php echo e(old('code')); ?>" autocomplete="off">
                                    <span class="text-danger"><?php echo e($errors->first('code')); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6">
                            <div class="form-group row">
                                <label for="nom" class="col-12 col-lg-3 text-right control-label col-form-label">Nom:</label>
                                <div class="col-12 col-lg-8">
                                    <input type="text" class="form-control" id="nom" placeholder="Saisir le nom de l'agent" name="nom" value="<?php echo e(old('nom')); ?>" autocomplete="off">
                                    <span class="text-danger"><?php echo e($errors->first('nom')); ?></span>
                                </div>
                                <div class="col-lg-1"></div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-lg-6">
                            <div class="form-group row">
                                <label for="prenom" class="col-12 col-lg-4 text-right control-label col-form-label">Prénom:</label>
                                <div class="col-12 col-lg-8">
                                    <input type="text" class="form-control" id="prenom" placeholder="Saisir le prénom de l'agent" name="prenom" value="<?php echo e(old('prenom')); ?>" autocomplete="off">
                                    <span class="text-danger"><?php echo e($errors->first('prenom')); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6">
                            <div class="form-group row">
                                <label for="pole_id" class="col-12 col-lg-3 text-right control-label col-form-label">Pole:</label>
                                <div class="col-12 col-lg-8">
                                    <select name="pole_id" class="form-control" id="pole_id">
                                        <option selected>------Choisir le pole de l'agent---------</option>
                                        <?php $__currentLoopData = $poles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($pole->id); ?>"><?php echo e($pole->libelle); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger"><?php echo e($errors->first('pole_id')); ?></span>
                                </div>
                                <div class="col-lg-1"></div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="email" class="col-12 col-lg-2 text-right control-label col-form-label">Adresse email:</label>
                        <div class="col-12 col-lg-9">
                            <input type="email" class="form-control" id="email" placeholder="Saisir l'email ici" name="email" value="<?php echo e(old('prenom')); ?>" autocomplete="off">
                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                        </div>
                    </div>
                    <div class="border-top">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-7">
                                </div>
                                <div class="col-lg-2">
                                    <button type="submit" class="btn btn-lg btn-primary text-center"><i class="fas fa-check"></i> Valider</button>
                                </div>
                                <div class="col-lg-2">
                                    <button type="reset" class="btn btn-lg btn-warning text-center"><i class="fas fa-window-close"></i> Annuler</button>
                                </div>
                                <div class="col-lg-1">
                                </div>
                            </div>
                        </div>
                    </div>
                </fieldset>
            </form><br>
            <?php if($agents->isNotEmpty()): ?>
                <h2 class="text-center">Liste des agents enregistrés</h2>
                <table class="table table-striped mb-2">
                    <thead>
                        <tr>
                            <th >Code</th>
                            <th >Nom</th>
                            <th >Prénom</th>
                            <th >Pole</th>
                            <th >Adresse email</th>
                            <th >Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->code); ?></td>
                                <td><?php echo e($item->nom); ?></td>
                                <td><?php echo e($item->prenom); ?></td>
                                <td><?php echo e($item->libelle); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="<?php echo e('#agent'.$item->id); ?>" data-backdrop="static"> <i class="fas fa-edit"></i> Modifier </button>
                                    <?php echo $__env->make('parametres.modals.agent_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h3 class="text-center">Aucun agent enregistré!</h3>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function(){
        if ($("#agent_form").length > 0) {
            $("#agent_form").validate({
        
                rules: {
                    code: {
                        required: true,
                        maxlength: 6,
                    },
                
                    nom: {
                        required: true,
                        maxlength: 50,
                    },

                    prenom: {
                        required: true,
                        maxlength: 50,
                    },

                    pole_id: {
                        required: true,
                        number: true,
                    },

                },
                messages: {
        
                    code: {
                        required: "Vous devez saisir le code de l'agent",
                        maxlength: "Le code de la l'agent a au plus 6 caractères"
                    },
                
                    nom: {
                        required: "Vous devez saisir le nom de la caissière",
                        maxlength: "Le nom de la l'agent a au plus 50 caractères",
                    },

                    prenom: {
                        required: "Vous devez saisir le nom de la caissière",
                        maxlength: "Le nom de l'agent a au plus 50 caractères",
                    },

                    pole_id: {
                        required: "Vous devez choisir le pole de l'agent",
                        number: "Vous devez choisir le pole de l'agent",
                    },
                    
                },
            });
        } 
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Cours\Mes_professionnels\a2sys\depenses\resources\views/parametres/agent.blade.php ENDPATH**/ ?>