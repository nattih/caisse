
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <h4 class="card-title m-b-0">Détails approvisionnement:</h4>
    </div>
    <div class="comment-widgets scrollable">
        <!-- Comment Row -->
        <div class="d-flex flex-row m-t-0">
            <div class="p-2">
                
            </div>
            <div class="comment-text w-100">
                <h6 class="font-medium">Date: <?php echo e($appro->dateAppro); ?></h6><br>
                <h6 class="font-medium">Type: <?php echo e($appro->libelle); ?></h6><br>
                <h6 class="font-medium">Montant: <?php echo e($appro->montantAppro); ?></h6><br>
                <h6 class="font-medium">
                    <?php if($appro->source == 1): ?>
                        Source: Banque
                    <?php else: ?>
                        Source: Remboursement
                    <?php endif; ?>
                    
                </h6><br>
                
                <div class="comment-footer">
                    
                <a href="<?php echo e(route('approvisionnement.validate', $appro->id)); ?>" class="btn btn-success btn-sm">Valider</a>
                <a href="<?php echo e(route('approvisionnement.rejeter', $appro->id)); ?>"  class="btn btn-cyan btn-sm">Rejeter</a>
                <a href="<?php echo e(route('approvisionnement_to_validate.get')); ?>" class="btn btn-danger btn-sm">Fermer</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Cours\Mes_professionnels\a2sys\caisse\depenses\resources\views/validations/validate_approvisionnement.blade.php ENDPATH**/ ?>