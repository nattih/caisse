<!-- The Modal -->
<div class="modal fade modal-agent" id="<?php echo e('agent'.$item->id); ?>">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header bg-dark text-white">
          <h4 class="modal-title">Modification d'un agent</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
      <form action="<?php echo e(route('agent.update', $item->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
          <!-- Modal body -->
          <div class="modal-body">
          <div class="form-group row">
              <label for="code" class="col-12 col-lg-3 text-right control-label col-form-label">Code:</label>
              <div class="col-12 col-lg-9">
              <input type="text" class="form-control" id="code" placeholder="Saisir le code" name="code" value="<?php echo e($item->code); ?>" autocomplete="off">
                  <span class="text-danger"><?php echo e($errors->first('code')); ?></span>
              </div>
          </div>
          <div class="form-group row">
              <label for="nom" class="col-12 col-lg-3 text-right control-label col-form-label">Nom:</label>
              <div class="col-12 col-lg-9">
                  <input type="text" class="form-control" id="nom" placeholder="Saisir le nom de l'agent" name="nom" value="<?php echo e($item->nom); ?>" autocomplete="off">
                  <span class="text-danger"><?php echo e($errors->first('nom')); ?></span>
              </div>
              
          </div>
          <div class="form-group row">
              <label for="prenom" class="col-12 col-lg-3 text-right control-label col-form-label">Prénom:</label>
              <div class="col-12 col-lg-9">
                  <input type="text" class="form-control" id="prenom" placeholder="Saisir le prénom de l'agent" name="prenom" value="<?php echo e($item->prenom); ?>" autocomplete="off">
                  <span class="text-danger"><?php echo e($errors->first('prenom')); ?></span>
              </div>
          </div>
          <div class="form-group row">
              <label for="pole_id" class="col-12 col-lg-3 text-right control-label col-form-label">Pole:</label>
              <div class="col-12 col-lg-9">
                  <select name="pole_id" class="form-control" id="pole_id">
                      <option value="<?php echo e($item->id); ?>" selected><?php echo e($item->libelle); ?></option>
                      <?php $__currentLoopData = $poles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(($pole->id <> $item->pole_id) && ($pole->libelle <> $item->libelle)): ?>
                          <option value="<?php echo e($pole->id); ?>"><?php echo e($pole->libelle); ?></option>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <span class="text-danger"><?php echo e($errors->first('pole_id')); ?></span>
              </div>
          </div>
          <div class="form-group row">
              <label for="email" class="col-12 col-lg-3 text-right control-label col-form-label">Adresse email:</label>
              <div class="col-12 col-lg-9">
                  <input type="email" class="form-control" id="email" placeholder="Saisir l'email ici" name="email" value="<?php echo e($item->email); ?>" autocomplete="off">
                  <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
              </div>
          </div>
          </div>
          
          <!-- Modal footer -->
          <div class="modal-footer">
            <button type="submit" class="btn btn-success">Modifier</button>
            <button type="button" class="btn btn-warning" data-dismiss="modal">fermer</button>
          </div>
        </form>
      </div>
    </div>
  </div><?php /**PATH D:\Cours\Mes_professionnels\a2sys\depenses\resources\views/parametres/modals/agent_modal.blade.php ENDPATH**/ ?>