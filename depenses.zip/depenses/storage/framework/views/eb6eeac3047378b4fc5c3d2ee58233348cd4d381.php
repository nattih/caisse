            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer text-center">
                All Rights Reserved by ELO-TECH. Designed and Developed by <a href="https://elo-tech.com">ELO-TECH</a>.
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== --><?php /**PATH H:\Cours\Mes_professionnels\coopel\leguema\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>