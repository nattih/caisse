
<?php $__env->startSection('css'); ?>
    <style>
        .table {
            margin: auto;
            width: 50% !important;  
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 col-lg-12">
        <div class="card">
            <form class="form-horizontal" id="agent_form" action="<?php echo e(route('project.save')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <fieldset>
                    <legend>Projets</legend>
                    <div class="form-group row">
                        <label for="intitule" class="col-12 col-lg-2 text-right control-label col-form-label">Code:</label>
                        <div class="col-12 col-lg-9">
                            <input type="text" class="form-control" id="intitule" placeholder="Saisir le code ici" name="intitule" autocomplete="off">
                            <span class="text-danger"><?php echo e($errors->first('intitule')); ?></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="description" class="col-12 col-lg-2 text-right control-label col-form-label">Description:</label>
                        <div class="col-12 col-lg-9">
                            <textarea class="form-control" id="description" name="description"></textarea>
                            <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                        </div>
                    </div>
                    <div class="border-top">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-9">
                                </div>
                                <div class="col-lg-2">
                                    <button type="submit" class="btn btn-lg btn-primary text-center"><i class="fas fa-plus"></i> Ajouter</button>
                                </div>
                                <div class="col-lg-1">
                                </div>
                            </div>
                        </div>
                    </div>
                </fieldset>
            </form><br>
            <?php if($projets->isNotEmpty()): ?>
            <h2 class="text-center">Liste des projets enregistrées</h2>
                <table class="table table-striped mb-2">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Description</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->intitule); ?></td>
                                <td><?php echo e($item->description); ?></td>
                                <td>
                                    <a href="#" class="btn btn-sm btn-success"> <i class="fas fa-edit"></i> Modifier </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h3 class="text-center">Aucun projet enregistré!</h3>
            <?php endif; ?>
            <div class="row mt-2 mb-2">
                <div class="col-lg-5"></div>
                <div class="col-lg-2">
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-lg btn-warning">Fermer</a>
                </div>
                <div class="col-lg-5"></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function(){
        if ($("#agent_form").length > 0) {
            $("#agent_form").validate({
        
                rules: {
                    intitule: {
                        required: true,
                        true: true,
                    },
                },
                messages: {
        
                    intitule: {
                        required: "Le code est obligatoire",
                        unique: "Le code ne doit pas être dupliqué"
                    },
                },
            });
        } 
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Cours\Mes_professionnels\a2sys\depenses\resources\views/parametres/projets.blade.php ENDPATH**/ ?>