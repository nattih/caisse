            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer text-center">
                ©Copyright <?= date('Y'); ?> <a href="https://www.a2sysconsulting.com">A2SYS Consulting</a> - Tous droits réservés.
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== --><?php /**PATH D:\Cours\Mes_professionnels\a2sys\caisse\depenses\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>