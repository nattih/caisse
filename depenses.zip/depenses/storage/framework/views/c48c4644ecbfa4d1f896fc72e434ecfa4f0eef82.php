
<?php $__env->startSection('css'); ?>
    <style>
        .table {
            margin: auto;
            width: 50% !important;  
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 col-lg-12">
        <div class="card">
            <form class="form-horizontal" id="agent_form" action="<?php echo e(route('nature_depense.save')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <fieldset>
                    <legend>Nature dépense</legend>
                    <div class="form-group row">
                        <label for="designation" class="col-12 col-lg-2 text-right control-label col-form-label">Code:</label>
                        <div class="col-12 col-lg-9">
                            <input type="text" class="form-control" id="designation" placeholder="Saisir le code ici" name="designation" autocomplete="off">
                            <span class="text-danger"><?php echo e($errors->first('designation')); ?></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="description" class="col-12 col-lg-2 text-right control-label col-form-label">Libellé:</label>
                        <div class="col-12 col-lg-9">
                            <input type="text" class="form-control" id="description" name="description" placeholder="saisir le libellé ici" autocomplete="off">
                            <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                        </div>
                    </div>
                    <div class="border-top">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-9">
                                </div>
                                <div class="col-lg-2">
                                    <button type="submit" class="btn btn-lg btn-primary text-center"><i class="fas fa-plus"></i> Ajouter</button>
                                </div>
                                <div class="col-lg-1">
                                </div>
                            </div>
                        </div>
                    </div>
                </fieldset>
            </form><br>
            <?php if($natureDepenses->isNotEmpty()): ?>
                <h2 class="text-center">Natures dépense enregistrées</h2>
                <table class="table table-striped mb-2">
                    <thead>
                        <tr>
                            <th >Code</th>
                            <th >Description</th>
                            <th >Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $natureDepenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->designation); ?></td>
                                <td><?php echo e($item->description); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="<?php echo e('#agent'.$item->id); ?>" data-backdrop="static"> <i class="fas fa-edit"></i> Modifier </button>
                                    <?php echo $__env->make('parametres.modals.type_depense_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h3 class="text-center">Aucune nature de dépense enregistrée!</h3>
            <?php endif; ?>
            <div class="row mt-2 mb-2">
                <div class="col-lg-5"></div>
                <div class="col-lg-2">
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-lg btn-warning">Fermer</a>
                </div>
                <div class="col-lg-5"></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function(){
        if ($("#agent_form").length > 0) {
            $("#agent_form").validate({
        
                rules: {
                    designation: {
                        required: true,
                        unique: true,
                    },

                    description: {
                        required: true,
                    },
                },
                messages: {
        
                    designation: {
                        required: "Le code est obligatoire",
                        unique: "Le code ne doit pas être dupliqué"
                    },

                    description: {
                        required: "Le libellé est obligatoire",
                    },
                },
            });
        } 
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Cours\Mes_professionnels\a2sys\depenses\resources\views/parametres/nature_depense.blade.php ENDPATH**/ ?>