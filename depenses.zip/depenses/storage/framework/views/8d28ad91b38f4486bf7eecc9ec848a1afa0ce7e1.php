
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <h4 class="card-title m-b-0">Détail dépense:</h4>
    </div>
    <div class="comment-widgets scrollable">
        <!-- Comment Row -->
        <div class="d-flex flex-row m-t-0">
            <div class="p-2"><img src="<?php echo e(asset('storage/'.$depense->filePath)); ?>" alt="user" width="100%" height="100%"></div>
            <div class="comment-text w-100">
                <h6 class="font-medium">Date: <?php echo e($depense->dateDepense); ?></h6><br>
                <h6 class="font-medium">Nature: <?php echo e($depense->designation); ?></h6><br>
                <h6 class="font-medium">Montant: <?php echo e($depense->montant); ?></h6><br>
                <h6 class="font-medium">Fournisseur: <?php echo e($depense->fournisseur); ?></h6><br>
                <span class="m-b-15 d-block">Description: <?php echo e($depense->description); ?>. </span>
                <span class="m-b-15 d-block">Commentaire: <?php echo e($depense->commentaire); ?>. </span>
                <div class="comment-footer">
                    
                <a href="<?php echo e(route('depense.validate', $depense->id)); ?>" class="btn btn-success btn-sm">Valider</a>
                <a href="<?php echo e(route('depense.rejeter', $depense->id)); ?>"  class="btn btn-cyan btn-sm">Rejeter</a>
                <a href="<?php echo e(route('depense_to_validate.get')); ?>" class="btn btn-danger btn-sm">Fermer</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Cours\Mes_professionnels\a2sys\depenses\resources\views/validations/validate_depense.blade.php ENDPATH**/ ?>