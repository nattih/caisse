
<?php $__env->startSection('content'); ?>
    <h1>Graphe des dépenses</h1>

    <div style="width: 50%; margin-left:15%;">
        <?php echo $depenseChart->container(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php if($depenseChart): ?>
    <?php echo $depenseChart->script(); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Cours\Mes_professionnels\a2sys\depenses\resources\views/c_dashboard.blade.php ENDPATH**/ ?>