<!DOCTYPE html>
<html dir="ltr" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('my_lib/assets/images/logo-a2sys.png')); ?>">
    <title>A2SYS-GESTION DE LA CAISSE</title>
    <!-- Custom CSS -->
    
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('css/boots/bootstrap.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/jq/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jq/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jq/poper.min.js')); ?>"></script>
    <link href="<?php echo e(asset('my_lib/dist/css/style.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/main_style.css')); ?>" rel="stylesheet">
    
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <?php echo $__env->make('layouts.partials.flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    
    
    <script src="<?php echo e(asset('my_lib/dist/js/jquery.validate.min.js')); ?>"></script>
    <!-- Bootstrap tether Core JavaScript -->
    
    <script src="<?php echo e(asset('my_lib/assets/libs/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('my_lib/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('my_lib/assets/extra-libs/sparkline/sparkline.js')); ?>"></script>
    <!--Wave Effects -->
    <script src="<?php echo e(asset('my_lib/dist/js/waves.js')); ?>"></script>
    <!--Menu sidebar -->
    <script src="<?php echo e(asset('my_lib/dist/js/sidebarmenu.js')); ?>"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo e(asset('my_lib/dist/js/custom.min.js')); ?>"></script>
    <!--This page JavaScript -->
    <!-- <script src="dist/js/pages/dashboards/dashboard1.js"></script> -->
    <!-- Charts js Files -->
    

    <script src="<?php echo e(asset('my_lib/assets/libs/inputmask/dist/min/jquery.inputmask.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('my_lib/dist/js/pages/mask/mask.init.js')); ?>"></script>
    
    <script src="<?php echo e(asset('my_lib/assets/libs/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/Chart.min.js')); ?>" charset=utf-8></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html><?php /**PATH H:\Cours\Mes_professionnels\a2sys\depenses\resources\views/layouts/master.blade.php ENDPATH**/ ?>